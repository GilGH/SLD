import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

export default function VistaJugador() {
  return (
    <View>
      <Text>VistaJugador</Text>
    </View>
  )
}

const styles = StyleSheet.create({})